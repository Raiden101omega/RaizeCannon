# Raizecannon 2.0

Biotechnology expansion for Mindustry Build 154.

## Rebuild basis

This release was rebuilt using two uploaded mods as structural references:

- **Floatydustry** — explicit JSON unit definitions and `UnitFactory.plans` production layout.
- **Upgraded Tiers** — clear tiered content organization, research progression, and explicit JSON block definitions.

The biotech theme, Parasitic Nanites, status effects, turrets, and 4-tier unit line remain Raizecannon content.

## Unit progression

Nanite Constructor:
- Raize Larva
- Raize Stalker
- Raize Wasp

Nanite Recombinator:
- Brood Crawler
- Spine Hunter
- Miasma Wasp

Mutagenic Reconstructor:
- Carapace Beast
- Plague Stalker
- Venom Wing

Apex Reconstructor:
- Colossus Worm
- Necrotic Warden
- Hive Mother

All factory and upgrade recipes use explicit JSON structures. The base constructor uses `plans`, while reconstructor upgrades use unit-side `requirements` objects, matching Mindustry's content parser behavior.

## Nanite Thrower

The Nanite Thrower only accepts Parasitic Nanites and explicitly sets the liquid on its `LiquidBulletType`.

## Sprite organization

Sprites are separated into `units`, `blocks`, `items`, `liquids`, and `status` pages. All PNGs are retained as 32-bit RGBA assets.

