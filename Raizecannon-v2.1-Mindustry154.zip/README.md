# Raizecannon 2.1

Biotechnology expansion for Mindustry build 154+.

## What this mod adds

- **Parasitic Nanites** — a custom liquid grown by the Nanite Culture Vat from
  spore pods, plastanium and water. Every unit factory and reconstructor in this
  mod drinks it while producing.
- **Nanite Infection / Spore Sludge** — two status effects delivered by unit
  weapons, the Biophage turret and the Nanite Thrower.
- **Biophage** — an organic anti-air flak turret with a three-shot salvo
  (surge alloy / plastanium / spore pod ammo).
- **Nanite Thrower** — a liquid turret that fires Parasitic Nanites only.
- **A 4-tier, 3-line unit roster** (12 units) grown through the
  Nanite Constructor and three reconstructors.

## Unit progression

Nanite Constructor (T1):
- Raize Larva / Raize Stalker / Raize Wasp

Nanite Recombinator (T2 upgrades):
- Brood Crawler / Spine Hunter / Miasma Wasp

Mutagenic Reconstructor (T3 upgrades):
- Carapace Beast / Plague Stalker / Venom Wing

Apex Reconstructor (T4 upgrades):
- Colossus Worm / Necrotic Warden / Hive Mother

The base constructor uses explicit `plans`; the reconstructor upgrades use the
unit-side `requirements` objects (`block` + `previous`), which Mindustry's
content parser turns into reconstructor upgrade pairs.

## Production chain

Cultivator (vanilla) -> **Spore Pod** (vanilla item)
Nanite Culture Vat: 1 Spore Pod + 1 Plastanium + water -> Parasitic Nanites
Nanite Constructor / Reconstructors: Parasitic Nanites + power + items -> units

This mod uses the **vanilla Spore Pod** item everywhere (recipes, research
costs, turret ammo); it does not define its own copy.

## Notes for build 154

- Power usage is declared through `consumes.power` (a top-level `consumePower`
  key is not a field and would be ignored).
- The Biophage salvo is a `ShootBarrel` shoot pattern; `shots`/`shotDelay` are
  not top-level turret fields in v7.
- Unit display names come from the JSON `name` field (`displayName` is not a
  recognized key).
- Status effect damage-over-time uses `intervalDamage`/`intervalDamageTime`
  (`damage` is per-frame damage and `damageInterval` does not exist).
- All weapons have sprites under `sprites/units/<unit>-weapon.png`; weapons
  look up sprites strictly by name.

## Sprite organization

Sprites live in `sprites/units`, `sprites/blocks`, `sprites/liquids` and
`sprites/status`. All PNGs are 32-bit RGBA; block sprites match their block
size (3x3 -> 96x96, 2x2 -> 64x64), and reconstructors ship `-in`/`-out`/`-top`
variants.
